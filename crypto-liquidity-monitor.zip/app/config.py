from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    telegram_bot_token: str
    xrocket_api_base_url: str = "https://exchange.api.xrocket.com"
    symbol: str = "TON/USDT"
    collect_interval_seconds: int = 10
    database_url: str = (
        "postgresql+asyncpg://analytics:analytics@postgres:5432/analytics"
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=False,
        extra="ignore",
    )


settings = Settings()
